import java.util.Random;

public class Jugador{


    final String[] accionesJugador = {"BOTAR_PELOTA","DRIBLAR","PASAR","TIRO_3_PUNTOS","TIRO_2_PUNTOS","TIRO_1_PUNTO","MATE","COMETER_FALTA"};


}
