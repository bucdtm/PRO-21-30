public interface Jugable {



}
