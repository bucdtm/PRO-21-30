import java.util.Objects;

public class Participante {


}
