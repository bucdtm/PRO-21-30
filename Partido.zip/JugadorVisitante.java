import java.util.Random;

public class JugadorVisitante{


}
