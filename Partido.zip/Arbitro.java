import java.util.Random;

public class Arbitro{


    final String[] accionesArbitro = {"ANULAR_CANASTA","ANOTAR_1_PUNTO","ANOTAR_2_PUNTOS","ANOTAR_3_PUNTOS","PASOS","FALTA","EXPULSION"};

     /*
        .............
         */
}
